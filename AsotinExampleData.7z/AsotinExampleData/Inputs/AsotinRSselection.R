
#This script uses information within ReachSelectionCriteria.csv to select reaches within the GUT database
#that match geomorphically to specified geomorphic indicator characteristics. 

#Natalie Kramer (n.kramer.anderson@gmail.com)
#Last Updated Dec 7, 2018


#Local location of database
DATAdir="E://GitHub//GeomorphicUpscale//Database"
#User defined project directories Loation
PROJdir='E:\\GitHub\\GeomorphicUpscale\\AsotinExampleData'
criteriafile=paste(PROJdir, "\\Inputs\\AsotinReachSelectionCriteria.csv", sep="")

#Specify location of R Mapping Script
#CODEdir= paste(PROJdir, "scripts", sep="\\")
#MapsbyRSselection=paste(CODEdir, "MapsbyRSselection.R", sep="\\")

#reads in user defined criteria
INdir=paste(PROJdir, "Inputs", sep="\\")
criteria=read.csv(criteriafile, skip=20) #skip= specifies # header rows to skip at beginning of csv, you may need to change
head(criteria)

#reads in database of reach variables.
data=read.csv(paste(DATAdir, "Database_reachcharacteristics.csv", sep="\\"))
head(data)

###########################################################
#Dependencies
###########################################################
#load('E:\\GitHub\\GeomorphicUpscale\\UnitSummary.R') #isn't reading in correctly?
library(dplyr)

####################

#FCpoor=FCpoor[-1,] #eliminate visit 1164 based on map review


###########################################################
#Selections
###########################################################
#selections for each river style and type.  Manually edit these to match criteria in your selection
#criteria look up table.  sorry this isn't more automated. But, this is a template which provides you
#with maximum flexibility to select as stringently or as un stringent as you desire. The trick is
#The trick is not to be too restrictive so that you end up with a large enough pool of sites 
#to acquire a good empirical estimate, but not so restrictive that you end up with sites that 
#don't look like your defined River Style.
criteria






#Since all Asotin streams are boulder-cobble-gravel.  I want to eliminate from the data
#All streams with sand size fraction greater than 50%

sandystreams=data1%>%
  filter(Sndf>50)
sandystreams #this search will eliminate four reaches visits 820,1971,2288,3975

data=data1%>%
  filter(Sndf<50)


## Asotin RS Example Selection


####get rid of streams wit too much sand
data1=data%>%
  filter(Sndf<50)#changes dataset so that they don't have sand entries (isits 820,1971,2288,3975)



# Fan Controlled-poor (FC poor) -----------------------------------------------------
criteria[1,]
FCpoor=data1%>%
  filter((Gradient < 3.5 & Gradient>1) 
         & Threads=="Single" 
         & (Bedform=="Plane-Bed")
         & Sinuosity<1.1 
         & Confinement!="UCV" 
         & (LWfreq < 30 | is.na(LWfreq))
         
  )
FCpoor$RScond="FCpoor"
FCpoor


# Fan Controlled-mod (FC mod)-----------------------------------------------------

criteria[2,]
FCmod=data%>%
  filter(
    (Gradient < 3.5 & Gradient>1) 
    & Threads=="Single" 
    & (Bedform=="Plane-Bed"| Bedform=="Pool-Riffle")  
    & (Sinuosity<1.3 & Sinuosity>1.04) 
    & Confinement!="UCV"  
    & (LWfreq < 60  | is.na(LWfreq))
  )
FCmod$RScond="FCmod"
FCmod


# Fan Controlled-good (FC good) -----------------------------------------------------
criteria[3,]
FCgood=data%>%
  filter(
    (Gradient < 3.5 & Gradient>1) 
    & Threads!="Multi" 
    & Bedform!="Plane-Bed"
    & (Sinuosity<1.5 & Sinuosity>1.1) 
    & Confinement!="UCV" 
    #& (LWfreq > 10 | is.na(LWfreq))
  )
FCgood$RScond="FCgood"
FCgood

# Fan Controlled-intact (FC intact)----------------------------------------------
criteria[4,]
FCintact=data%>%
  filter((Gradient < 3.5 & Gradient>1) 
         & Threads!="Multi" 
         & Bedform!="Plane-Bed"
         & (Sinuosity<1.5 & Sinuosity>1.1 )
         & Confinement!="UCV"  
         & (LWfreq > 40  | is.na(LWfreq))
  )
FCintact$RScond="FCintact"
FCintact

# Alluvial Fan-poor (AF poor) -----------------------------------------------------
criteria[5,]
AFpoor=data%>%
  filter(
    Gradient < 3  
    & Threads=="Single" 
    & Bedform=="Plane-Bed" 
    & Sinuosity<1.2
    & Confinement!="CV"  
    & (LWfreq < 30 | is.na(LWfreq))
  )
AFpoor$RScond="AFpoor"
AFpoor

# Alluvial Fan-mod (AF mod) -----------------------------------------------------

criteria[6,]
AFmod=data%>%
  filter(
    Gradient < 3 
    & (Threads=="Single" | Threads=="Transitional")
    & Bedform=="Plane-Bed" 
    & Sinuosity<1.3
    & Confinement!="CV"  
    & ((LWfreq < 60 & LWfreq > 10)| is.na(LWfreq))
  )
AFmod$RScond="AFmod"
AFmod


# Alluvial Fan-good (AF good) -----------------------------------------------------
criteria[7,]
AFgood=data%>%
  filter(
    Gradient < 3 
    & (Threads=="Single" | Threads=="Transitional" | Threads=="Multi")
    & (Braid < 5)
    & (Bedform=="Plane-Bed" | Bedform=="Pool-Riffle")
    & (Sinuosity<1.5 & Sinuosity >1.1)
    & Confinement!="CV" 
    & (LWfreq > 20| is.na(LWfreq))
  )
AFgood$RScond="AFgood"
AFgood

# Alluvial Fan-good (AF intact) -----------------------------------------------------
criteria[8,]
AFintact=data%>%
  filter(
    Gradient < 3 
    & (Threads=="Single" | Threads=="Transitional"| Threads=="Multi")
    #& (Braid < 5)
    & (Bedform=="Plane-Bed" | Bedform=="Pool-Riffle")
    & (Sinuosity<1.5 & Sinuosity >1.1)
    & Confinement!="CV" 
    & (LWfreq > 40| is.na(LWfreq))
  )
AFintact$RScond="AFintact"
AFintact


# Planform Controlled-poor (PC poor) -----------------------------------------------------
criteria[9,]
PCpoor=data%>%
  filter(
    Gradient < 2.5  
    & Threads=="Single" 
    & Bedform=="Plane-Bed" 
    & Sinuosity<1.1 
    & Confinement!="CV"
    & (LWfreq<30| is.na(LWfreq))
  )
PCpoor$RScond="PCpoor"
PCpoor



# Planform Controlled-mod (PC mod) -----------------------------------------------------

criteria[10,]
PCmod=data%>%
  filter(
    Gradient < 2.5 
    & (Threads=="Single" | Threads=="Transitional")
    & Braid<1.2
    & (Bedform=="Plane-Bed"| Bedform=="Pool-Riffle")  
    & (Sinuosity>1.1 & Sinuosity<1.5) 
    & Confinement!="CV" 
    & ((LWfreq>5 & LWfreq<60) | is.na(LWfreq))
  )
PCmod$RScond="PCmod"
PCmod

#PCmodsum=percAreasummary(PCmod)
#PCmodsum$RScond="PC mod"
#head(PCmodsum)


# Planform Controlled-good (PC good) -----------------------------------------------------
criteria[11,]
PCgood=data%>%
  filter(
    Gradient < 2.5 
    & Threads!="Multi" 
    & Bedform=="Pool-Riffle"
    & (Sinuosity<1.5 & Sinuosity>1.1) 
    & Confinement!="CV"
    &((LWfreq>10 & LWfreq<100) | is.na(LWfreq))
  )
PCgood$RScond="PCgood" 
PCgood

#PCgoodsum=percAreasummary(PCgood)
#PCgoodsum$RScond="PC good" 
#head(PCgoodsum)
# Planform Controlled-good (PC intact) -----------------------------------------------------

criteria[12,]
PCintact=data%>%
  filter(
    Gradient < 2.5 
    & Threads!="Single" 
    & Bedform!="Plane-Bed"
    & (Sinuosity<1.5 & Sinuosity>1.1) 
    & Confinement!="CV"
    &((LWfreq>40) | is.na(LWfreq))
  )
PCintact$RScond="PCintact" 
PCintact

# Wandering-poor (WA poor) -----------------------------------------------------

criteria[13,]
WApoor=data%>%
  filter(
    Gradient < 2  
    & Threads=="Single"
    & Bedform=="Plane-Bed" 
    & Sinuosity<1.2
    & Confinement!="CV"
    & (LWfreq < 30 | is.na(LWfreq))
    
  )
WApoor$RScond="WApoor"
WApoor

# Wandering-mod (WA mod) -----------------------------------------------------

criteria[14,]
WAmod=data%>%
  filter(
    Gradient < 2 
    & (Threads=="Single" | Threads=="Transitional")
    & Braid<1.5
    & (Bedform=="Pool-Riffle" | Bedform=="Plane-Bed") 
    & (Sinuosity>1.2 & Sinuosity<1.3) 
    & Confinement!="CV" 
    & ((LWfreq < 60 & LWfreq>1) | is.na(LWfreq))
  )
WAmod$RScond="WAmod"
WAmod

# Wandering-good (WA good) -----------------------------------------------------
criteria[15,]
WAgood=data%>%
  filter(
    Gradient < 2 
    & Threads!="Single" 
    & Bedform!="Plane-Bed"
    & (Sinuosity>1.1 & Sinuosity<1.5)
    & Confinement!="CV" 
    & ((LWfreq>20) | is.na(LWfreq))
  )
WAgood$RScond="WAgood"
WAgood

# Wandering-intact (WA intact) -----------------------------------------------------
criteria[16,]
WAintact=data%>%
  filter(
    Gradient < 2 
    & Threads=="Multi" 
    & Bedform!="Plane-Bed"
    & (Sinuosity>1.1)
    & Confinement!="CV" 
    & ((LWfreq>40) | is.na(LWfreq))
  )
WAintact$RScond="WAintact"
WAintact

# Confined Valley-poor (CV poor) -----------------------------------------------------
criteria[17,]
CVpoor=data%>%
  filter(
    (Gradient >2 & Gradient <6) 
    & Threads=="Single" 
    & (Bedform=="Plane-Bed"| Bedform=="Rapid") 
    & Sinuosity<1.1
    & Confinement=="CV" 
  )
CVpoor$RScond="CVpoor"
CVpoor



# Confined Valley-mod (CV mod)-----------------------------------------------------
criteria[18,]
CVmod=data%>%
  filter(
    (Gradient>2 & Gradient<6)
    & Threads=="Single" 
    &  Bedform!="Plane-Bed" 
    & Sinuosity<1.1 
    & Confinement=="CV" )
CVmod$RScond="CVmod"
CVmod



# Confined Valley-(CV good) -----------------------------------------------------

criteria[19,]
CVgood=data%>%
  filter(
    (Gradient>2 & Gradient<6)
    & Threads!="Multi" 
    & Bedform!="Plane-Bed" 
    & Sinuosity<1.2 
    & Confinement=="CV" 
  )
CVgood$RScond="CVgood"
CVgood

# Confined Valley-(CV intact) -----------------------------------------------------

criteria[20,]
CVintact=data%>%
  filter(
    (Gradient>2 & Gradient<6)
    & Threads!="Multi" 
    & Bedform!="Plane-Bed" 
    & Sinuosity<1.3 
    & Confinement=="CV" 
  )
CVintact$RScond="CVintact"
CVintact


#Combining a visit list --------------------

#combine your selections above into one dataset
selections=rbind(FCpoor,FCmod, FCgood, FCintact,
                 AFpoor,AFmod, AFgood, AFintact,
                 PCpoor,PCmod, PCgood, PCintact,
                 WApoor, WAmod, WAgood,WAintact,
                 CVpoor, CVmod, CVgood, CVintact)


selectionfilename="Asotinselections"

write.csv(selections, paste(INdir, "\\", selectionfilename, ".csv",  sep=""), row.names=F) 


  