PROJdir="E:\\GitHub\\GeomorphicUpscale\\AsotinExampleData"
INdir=paste(PROJdir,"Inputs", sep="\\")

library(rgdal)

###fixing up network data####
network.sp=readOGR(paste(INdir,'\\AGA_Management_upscalingcapacity.shp', sep=""))
network.sp@data$RS=as.character(network.sp@data$RS)
network.sp@data$RS[which(startsWith(as.character(network.sp@data$RS),"C")==T)]="CV"


network.sp@data$RScurrent=gsub("CF","CV",network.sp@data$RScurrent)
network.sp@data$RScurrent=gsub("CB","CV",network.sp@data$RScurrent)
network.sp@data$RScurrent=gsub("CH","CV",network.sp@data$RScurrent)
network.sp@data$RSrestored=gsub("CF","CV",network.sp@data$RSrestored)
network.sp@data$RSrestored=gsub("CB","CV",network.sp@data$RSrestored)
network.sp@data$RSrestored=gsub("CH","CV",network.sp@data$RSrestored)
network.sp@data$RScurrent=gsub("moderate","mod",network.sp@data$RScurrent)
network.sp@data$RSrestored=gsub("moderate","mod",network.sp@data$RSrestored)
as.factor(network.sp@data$RScurrent)

network.sp@data=extract(network.sp@data, RScurrent, into = c("Condition0"), "([:lower:].*)", remove=F)
network.sp@data=extract(network.sp@data, RSrestored, into = c("Condition1"), "([:lower:].*)", remove=F)
network.sp@data=extract(network.sp@data, RSrestored, into = c("Condition2"), "([:lower:].*)", remove=F)
network.sp@data$Condition2[which(network.sp@data$Condition0=="good")]="intact"
network=network.sp@data[,c(1,3,7,28:29,37,31,33,35,36)]



write.csv(network, paste(INdir,"Asotinnetwork.csv", sep="\\"), row.names=F )
